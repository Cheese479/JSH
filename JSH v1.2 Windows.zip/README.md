JSH (James Shell) is a UNIX-like shell aimed for simplicity and power to be the succesor of Windows CMD and Bash Alright i'm back and this is version 1.2, I added save support for cookie clicker and some other cool stuff, but later I plan to add multitasking and pipes and a package manager though! I plan to have very advanced features by v2.0

