# JSH (James Shell) is a lightweight shell written in Python

It already has simple commands for file I/O and other stuff, but I plan to really build JSH out into something great
I'm making it a mix of UNIX and NT but also want it to be seperate
Eventually i'll add support for running .jsh script files and multitasking, maybe even building an optional GUI around it, that would make JSH more like an actual OS (which I want it to become)
But this is the first release so don't expect much, anyways thanks for checking out my project :)!

